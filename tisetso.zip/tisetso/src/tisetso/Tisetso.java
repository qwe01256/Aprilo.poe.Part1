package tisetso;

import java.util.Scanner;

public class Tisetso {

    // Variables
    String firstname;
    String secondName;
    String surname;
    String username;
    String Password;
    String cellNumber;

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Create user
        Tisetso user = new Tisetso();

        // First name
        System.out.println("Please enter your first name");
        user.firstname = input.nextLine();

        // Second name
        System.out.println("Please enter your second name");
        user.secondName = input.nextLine();

        // Surname
        System.out.println("Please enter your surname");
        user.surname = input.nextLine();

        // Cell number
        while (true) {

            System.out.println("Enter your phone number");
            user.cellNumber = input.nextLine();

            if (checkcellNumber(user.cellNumber)) {
                System.out.println("Phone number successfully added");
                break;
            } else {
                System.out.println("Phone number incorrectly formatted");
                System.out.println("Phone number must contain +27");
            }
        }

        // Username
        while (true) {

            System.out.println("Please enter your username");
            user.username = input.nextLine();

            if (checkusername(user.username)) {
                System.out.println("Username successfully entered");
                break;
            } else {
                System.out.println("Username is not correctly formatted");
                System.out.println("Username must contain an underscore");
                System.out.println("Username must be 5 characters or less");
            }
        }

        // Password
        while (true) {

            System.out.println("Please enter your password");
            user.Password = input.nextLine();

            if (checkPassword(user.Password)) {
                System.out.println("Password successfully captured");
                break;
            } else {
                System.out.println("Password is not correctly formatted");
                System.out.println("Password must contain at least 8 characters");
                System.out.println("Password must contain a capital letter");
                System.out.println("Password must contain a number");
                System.out.println("Password must contain a special character");
            }
        }

        // Register user
        String registrationMessage = user.registerUser(
                user.username,
                user.Password,
                user.cellNumber,
                user.firstname,
                user.secondName
        );

        System.out.println(registrationMessage);

        // Login
        boolean loginSuccessful = login.loginUser(
                input,
                user.username,
                user.Password,
                user.firstname,
                user.surname
        );

        // Display login status
        String loginMessage = login.returnLoginStatus(
                user,
                loginSuccessful
        );

        System.out.println(loginMessage);

        input.close();
    }

    // Check username
    public static boolean checkusername(String username) {

        return username.length() <= 5
                && username.contains("_");
    }

    // Check cell number
    public static boolean checkcellNumber(String cellNumber) {

        return cellNumber.startsWith("+27");
    }

    // Check password
    public static boolean checkPassword(String Password) {

        if (Password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (int i = 0; i < Password.length(); i++) {

            char ch = Password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasCapitalLetter = true;
            }

            if (Character.isDigit(ch)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(ch)) {
                hasSpecialCharacter = true;
            }
        }

        return hasCapitalLetter
                && hasNumber
                && hasSpecialCharacter;
    }
    
            

    // Register user
    public String registerUser(
            String username,
            String Password,
            String cellNumber,
            String firstname,
            String secondName) {

        if (!checkusername(username)) {

            return "Username is not correctly formatted. "
                    + "Username must contain an underscore "
                    + "and must be 5 characters or less.";
        }

        if (!checkPassword(Password)) {

            return "Password is not correctly formatted. "
                    + "Password must contain at least 8 characters, "
                    + "a capital letter, a number and a special character.";
        }

        if (!checkcellNumber(cellNumber)) {

            return "Cell number incorrectly formatted. "
                    + "It must contain the international code +27.";
        }

        return "Registration successfully completed.";
    }
}